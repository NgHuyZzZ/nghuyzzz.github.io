
import {
    ActionFormData, ModalFormData
} from "@minecraft/server-ui";



let rotation

export function MRG(source) {

    const mrg = new ActionFormData()
        .title("Created by§f: §5NgMinhHuy §0<- §4YouTube")
        .button('§8[§cExit§8]', 'textures/ui/icon_import.png');
    mrg.body("§ev1.0.9 \n§4§lWARNING§0§r: §fThere is no undo yet, make sure to backup your world.")
    mrg.button('§8[§cHouses§8]\n§r§7Tap to open', 'textures/ui/hammer_l.png')
    mrg.button('§8[§cFarms§8]\n§r§7Tap to open', 'textures/ui/MashupIcon.png')

    mrg.show(source).then(({ selection }) => { // MAIN MENU
        switch (selection) {
            case 0:
                source.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§¶§6House Build ► §dMENU §cCLOSED."}]}`)
                break;
            case 1:
                House(source);
                break;
            case 2:
                Farm(source);
                break;
        }
    });
}

function Farm(source) {

    const mrg = new ModalFormData()
        .title("§l§fFarms")
        .dropdown("Farms 1-18 available", ['Iron', 'Gold', 'Sugarcane', 'Bone Meal', 'Tree', 'Bamboo', 'Enderman', 'Cactus', 'Pumpkin', 'Watermelon', 'Honey', 'Stone', 'Basalt', 'Twisting Vines', 'Weeping Vines', 'Mob', 'Kelp', 'Bread'])
        .dropdown("Rotation", ['0_degrees', '90_degrees', '180_degrees', '270_degrees'], 0)
    mrg.show(source).then((response, canceled) => {
        switch (response.formValues[1]) {
            case 0:
                rotation = '0_degrees'
                break
            case 1:
                rotation = '90_degrees'
                break
            case 2:
                rotation = '180_degrees'
                break
            case 3:
                rotation = '270_degrees'
                break
        }
        if (canceled) return;
        switch (response.formValues[0]) {
            case 0:
                source.runCommandAsync(`structure load iron_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 1:
                source.runCommandAsync(`structure load gold_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 2:
                source.runCommandAsync(`structure load canes_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 3:
                source.runCommandAsync(`structure load bone_meal_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 4:
                source.runCommandAsync(`structure load auto_tree_farmz ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 5:
                source.runCommandAsync(`structure load bamboo_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 6:
                source.runCommandAsync(`structure load enderman_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 7:
                source.runCommandAsync(`structure load cactus_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 8:
                source.runCommandAsync(`structure load pumpkin_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 9:
                source.runCommandAsync(`structure load melon_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 10:
                source.runCommandAsync(`structure load honey_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 11:
                source.runCommandAsync(`structure load stone_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 12:
                source.runCommandAsync(`structure load tnt_basalt_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 13:
                source.runCommandAsync(`structure load twisting_vines_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 14:
                source.runCommandAsync(`structure load weeping_vines_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 15:
                source.runCommandAsync(`structure load mob_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 16:
                source.runCommandAsync(`structure load kelp_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 17:
                source.runCommandAsync(`structure load bread_farm ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            default:
                MRG(source);
                break;

        }
    })
};

function House(source) {
    const mrg = new ActionFormData()
    mrg.title("§l§fHouse Styles")
    mrg.body("-Made by mrgamingisop")
    mrg.button("§8[§cModern §dHouses§8]\n§7New modern generation houses")
    mrg.button("§8[§aMedieval §dHouses§8]\n§7Houses of 1100 and 1500 AD")
    mrg.button('§8[§cBack§8]', 'textures/ui/icon_import.png')
    mrg.show(source).then(({ selection }) => { // MAIN MENU
        switch (selection) {
            case 0:
                Modern(source)
                break;
            case 1:
                Medieval(source);
                break;
            default:
                MRG(source);
                break;
        }
    });
}

function Medieval(source) {
    const mrg = new ModalFormData()
        .title("§l§fMedieval Houses")
        .dropdown("Houses 1-18 available", ['Medieval 1', 'Medieval 2', 'Medieval 3', 'Medieval 4', 'Medieval 5', 'Medieval 6', 'Medieval 7', 'Medieval 8', 'Medieval 9', 'Medieval 10', 'Medieval 11', 'Medieval 12', 'Medieval 13', 'Medieval 14', 'Medieval 15', 'Medieval 16', 'Medieval 17', 'Medieval 18'])
        .dropdown("Rotation", ['0_degrees', '90_degrees', '180_degrees', '270_degrees'], 0)
    mrg.show(source).then((response, canceled) => {
        switch (response.formValues[1]) {
            case 0:
                rotation = '0_degrees'
                break
            case 1:
                rotation = '90_degrees'
                break
            case 2:
                rotation = '180_degrees'
                break
            case 3:
                rotation = '270_degrees'
                break
            default:
                MRG(source);
                break;
        }
        if (canceled) return;
        switch (response.formValues[0]) {
            case 0:
                source.runCommandAsync(`structure load md_1 ~-10 ~-1 ~-30 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 1:
                source.runCommandAsync(`structure load md_2 ~-8 ~-1 ~-20 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 2:
                source.runCommandAsync(`structure load md_3 ~-12 ~-2 ~-17 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 3:
                source.runCommandAsync(`structure load md_4 ~-21 ~-1 ~-20 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 4:
                source.runCommandAsync(`structure load md_5 ~-11 ~-1 ~-24 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 5:
                source.runCommandAsync(`structure load md_6 ~-11 ~-1 ~4 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 6:
                source.runCommandAsync(`structure load md_7 ~-8 ~-1 ~-15 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 7:
                source.runCommandAsync(`structure load md_8 ~1 ~-3 ~-25 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 8:
                source.runCommandAsync(`structure load md_9 ~-19 ~ ~-11 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 9:
                source.runCommandAsync(`structure load md_10 ~-14 ~-3 ~-16 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 10:
                source.runCommandAsync(`structure load tavern ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 11:
                source.runCommandAsync(`structure load quick_castle ~6~~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 12:
                source.runCommandAsync(`structure load castle1 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 13:
                source.runCommandAsync(`structure load castle2 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 14:
                source.runCommandAsync(`structure load house_medieval1 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 15:
                source.runCommandAsync(`structure load desert_house ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 16:
                source.runCommandAsync(`structure load medieval_house ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 17:
                source.runCommandAsync(`structure load medieval ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            default:
                MRG(source);
                break;
        }
    })
};

function Modern(source) {
    const mrg = new ModalFormData()
        .title("§l§fModern Houses")
        .dropdown("Houses 1-34 available", ['Modern House 1', 'Modern House 2', 'Modern House 3', 'Modern House 4', 'Modern House 5', 'Modern House 6', 'Modern House 7', 'Modern House 8', 'Modern House 9', 'Modern House 10', 'Modern House 11', 'Modern House 12', 'Modern House 13', 'Modern House 14', 'Modern House 15', 'Modern House 16', 'Modern House 17', 'Modern House 18', 'Modern House 19', 'Modern House 20', 'Modern House 21', 'Modern House 22', 'Modern House 23', 'Modern House 24', 'Modern House 25', 'Modern House 26', 'Modern House 27', 'Modern House 28', 'Modern House 29', 'Modern House 30', 'Modern House 31', 'Modern House 32', 'Modern House 33'])
        .dropdown("Rotation", ['0_degrees', '90_degrees', '180_degrees', '270_degrees'], 0)
    mrg.show(source).then((response) => {
        switch (response.formValues[1]) {
            case 0:
                rotation = '0_degrees'
                break
            case 1:
                rotation = '90_degrees'
                break
            case 2:
                rotation = '180_degrees'
                break
            case 3:
                rotation = '270_degrees'
                break
        }
        if (response.isCanceled) return;
        switch (response.formValues[0]) {
            case 0:
                source.runCommandAsync(`structure load mh_1 ~-7 ~ ~-12 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 1:
                source.runCommandAsync(`structure load mh_2 ~-15 ~-3 ~-36 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 2:
                source.runCommandAsync(`structure load mh_3 ~-20 ~-3 ~-43 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 3:
                source.runCommandAsync(`structure load mh_4 ~-20 ~-3 ~-33 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 4:
                source.runCommandAsync(`structure load mh_5 ~-20 ~-1 ~-39 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 5:
                source.runCommandAsync(`structure load mh_6 ~ ~-9 ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 6:
                source.runCommandAsync(`structure load mh_7 ~-7 ~-2 ~-33 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 7:
                source.runCommandAsync(`structure load mh_8 ~-17 ~-1 ~-26 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 8:
                source.runCommandAsync(`structure load mh_9 ~-44 ~-2 ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 9:
                source.runCommandAsync(`structure load mh_10 ~-12 ~-2 ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 10:
                source.runCommandAsync(`structure load mh_11 ~-10 ~-2 ~1 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 11:
                source.runCommandAsync(`structure load mh_12 ~-17 ~-2 ~1 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 12:
                source.runCommandAsync(`structure load mh_13 ~-14 ~-2 ~-1 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 13:
                source.runCommandAsync(`structure load mh_14 ~-17 ~-2 ~-30 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 14:
                source.runCommandAsync(`structure load mh_15 ~-16 ~-2 ~-43 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 15:
                source.runCommandAsync(`structure load mh_16 ~-14 ~-2 ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 16:
                source.runCommandAsync(`structure load mh_17 ~-21 ~-3 ~1 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 17:
                source.runCommandAsync(`structure load mh_18 ~-7 ~-1 ~-36 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 18:
                source.runCommandAsync(`structure load mh_19 ~-13 ~-3 ~-53 ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 19:
                source.runCommandAsync(`structure load mh_20 ~-40 ~-2 ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 20:
                source.runCommandAsync(`structure load house_0 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 21:
                source.runCommandAsync(`structure load house_1 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 22:
                source.runCommandAsync(`structure load house_2 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 23:
                source.runCommandAsync(`structure load house_3 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 24:
                source.runCommandAsync(`structure load house_4 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 25:
                source.runCommandAsync(`structure load house_5 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 26:
                source.runCommandAsync(`structure load house_modern1 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 27:
                source.runCommandAsync(`structure load house_modern2 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 28:
                source.runCommandAsync(`structure load house_modern3 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 29:
                source.runCommandAsync(`structure load house_modern4 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 30:
                source.runCommandAsync(`structure load house_modern5 ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 31:
                source.runCommandAsync(`structure load modern_house ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            case 32:
                source.runCommandAsync(`structure load beach_house ~6 ~ ~ ${rotation}`)
                source.runCommandAsync(`playsound random.levelup @s ~~~`)
                break
            default:
                MRG(source);
                break;
        }
    })
};